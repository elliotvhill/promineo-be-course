// Copyright (c) 2023 by Promineo Tech.

package dependency.injection.farm;

/**
 * This abstract class provides common methods for the derived concrete classes.
 * 
 * @author Promineo
 *
 */
public abstract class FarmAnimal implements Animal {

  /**
   * Declare an abstract method that must be implemented by a derived class.
   * 
   * @return A sound string (i.e., "oink", "moo", etc.).
   */
  protected abstract String makeSound();

  /**
   * The implementation of the speak method declared in the {@link Animal}
   * interface. It calls the {@link #makeSound()} method to print the sound.
   */
  @Override
  public void speak() {
    System.out.println("The " + this + " says " + makeSound() + ".");
  }

  /**
   * Implementation of the toString method. This just returns the simple name of
   * the concrete class (i.e., "Pig", or "Cow").
   */
  @Override
  public String toString() {
    return getClass().getSimpleName();
  }


}
