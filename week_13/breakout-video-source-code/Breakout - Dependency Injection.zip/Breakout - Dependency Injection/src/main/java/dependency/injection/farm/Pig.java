// Copyright (c) 2023 by Promineo Tech.

package dependency.injection.farm;

import org.springframework.stereotype.Component;

/**
 * This class extends the abstract class {@link FarmAnimal}. It provides the
 * required {@link #makeSound()} method.
 * 
 * @Component This tells Spring that the class is to have its lifecycle managed
 *            by Spring. A name is supplied so that @Qualifier can be used to
 *            select the required {@link Animal} object.
 * 
 * @author Promineo
 *
 */
@Component(value = "MyPig")
public class Pig extends FarmAnimal {

  /**
   * Returns a sound appropriate to a pig.
   */
  @Override
  protected String makeSound() {
    return "oink";
  }
}
