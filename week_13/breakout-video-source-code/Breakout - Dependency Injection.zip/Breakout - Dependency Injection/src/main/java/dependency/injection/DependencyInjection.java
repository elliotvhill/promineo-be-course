// Copyright (c) 2023 by Promineo Tech.

package dependency.injection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import dependency.injection.farm.Animal;

/**
 * This class starts Spring Boot. Once initialization of Boot is complete, the
 * {@link #run(String...)} method on {@link CommandLineRunner} is called.
 * 
 * @author Promineo
 *
 */
@SpringBootApplication
public class DependencyInjection implements CommandLineRunner {
  /*
   * Spring will inject a concrete class derived from Animal (Pig, Cow).
   * The @Qualifier annotation allows a specific concrete class to be selected
   * for injection.
   */
  @Autowired
  @Qualifier("cow")
  private Animal animal;

  /**
   * Start Spring Boot.
   * 
   * @param args Unused.
   */
  public static void main(String[] args) {
    SpringApplication.run(DependencyInjection.class, args);
  }

  /**
   * Called by Spring after initialization is complete.
   * 
   * @param args Unused.
   */
  @Override
  public void run(String... args) {
    animal.speak();
  }
}
