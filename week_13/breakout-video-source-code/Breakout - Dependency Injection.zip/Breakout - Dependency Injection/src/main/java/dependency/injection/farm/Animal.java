// Copyright (c) 2023 by Promineo Tech.

package dependency.injection.farm;

/**
 * This simple interface is used to demonstrate how to manage Dependency
 * Injection in a Spring application when there are multiple concrete classes
 * that implement this interface.
 * 
 * @author Promineo
 *
 */
public interface Animal {

  void speak();

}
