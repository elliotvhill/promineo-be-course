// Copyright (c) 2023 by Promineo Tech.

package dependency.injection.farm;

import org.springframework.stereotype.Component;

/**
 * This class extends the abstract class {@link FarmAnimal}. It provides the
 * required {@link #makeSound()} method.
 * 
 * @Component This tells Spring that the class is to have its lifecycle managed
 *            by Spring. A default name ("cow") is supplied by Spring so
 *            that @Qualifier can be used to select the required {@link Animal}
 *            object. Spring creates the default name by converting the class
 *            name to lower camel case.
 * 
 * @author Promineo
 *
 */
@Component
public class Cow extends FarmAnimal {

  /**
   * Return a sound appropriate to a cow.
   */
  @Override
  protected String makeSound() {
    return "moo";
  }

}
