This project demonstrates how to manage Dependency Injection (DI) in a Spring Boot application.

This is part of the Spring Boot video series by Promineo Tech. It provides supporting code for the  _Dependency Injection_  breakout.