// Copyright (c) 2023 by Promineo Tech.

package spring.jpa.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import spring.jpa.demo.entity.Breed;

/**
 * This interface simply extends {@link JpaRepository}. Spring JPA provides the
 * method implementations.
 * 
 * @author Promineo
 *
 */
public interface BreedDao extends JpaRepository<Breed, Long> {
}
