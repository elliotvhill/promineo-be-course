This project demonstrates how to write a one-to-many unidirectional relationship in Spring JPA. It is part of the Spring Boot segment in the backend course at Promineo Tech.

This project is featured in the breakout session  _Coding the One-to-Many Relationship in JPA_ .