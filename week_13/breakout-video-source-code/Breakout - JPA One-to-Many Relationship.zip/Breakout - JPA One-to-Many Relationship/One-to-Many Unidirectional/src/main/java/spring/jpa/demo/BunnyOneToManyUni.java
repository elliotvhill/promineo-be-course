// Copyright (c) 2023 by Promineo Tech.

package spring.jpa.demo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import spring.jpa.demo.entity.Breed;
import spring.jpa.demo.service.BreedService;

/**
 * This class starts Spring Boot and fetches all bunny breeds from the breed
 * tables.
 * 
 * @author Promineo
 *
 */
@SpringBootApplication
public class BunnyOneToManyUni implements CommandLineRunner {
  @Autowired
  private BreedService breedService;

  /**
   * Start Spring Boot.
   * 
   * @param args Unused.
   */
  public static void main(String[] args) {
    SpringApplication.run(BunnyOneToManyUni.class, args);
  }

  /**
   * This is called by Spring Boot once the application initialization is
   * complete. It is required by the {@link CommandLineRunner} interface.
   */
  @Override
  public void run(String... args) throws Exception {
    List<Breed> breeds = breedService.retrieveAllBreeds();
    breeds.forEach(System.out::println);
  }
}
