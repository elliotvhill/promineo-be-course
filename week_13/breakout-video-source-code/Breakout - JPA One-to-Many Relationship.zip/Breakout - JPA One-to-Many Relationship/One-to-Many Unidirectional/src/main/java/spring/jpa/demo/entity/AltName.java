// Copyright (c) 2023 by Promineo Tech.

package spring.jpa.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

/**
 * This class provides JPA with information on how to manage the alt_name table.
 * In the unidirectional many-to-many relationship, there is nothing needed in
 * this class. JPA creates and manages the relationship through the join table
 * defined in the {@link Breed} class.
 * 
 * @Entity Marks the class as one JPA will manage.
 * 
 * @Data Creates getters and setters for the instance variables. Also creates
 *       the .equals() and .hashCode() methods, as well as a .toString() method.
 * 
 * @author Promineo
 *
 */
@Entity
@Data
public class AltName {
  /*
   * @Id tells JPA that this is an identity (primary key) field. @GeneratedValue
   * tells JPA that the datasource will manage the primary key.
   */
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long alternateId;

  private String alternateName;
}
