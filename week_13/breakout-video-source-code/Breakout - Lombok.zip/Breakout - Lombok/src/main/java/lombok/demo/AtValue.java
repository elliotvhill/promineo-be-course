// Copyright (c) 2023 by Promineo Tech.

package lombok.demo;

import lombok.Value;

/**
 * This class demonstrates the use of the Lombok annotation, @Value. This
 * annotation is used to create an immutable object. The annotation adds an
 * all-argument constructor and provides getters for the instance variables but
 * not setters. Also added is .equals(), .hashCode(), and .toString(). To
 * demonstrate the annotation in practice, Lombok must be installed into the 
 * IDE. Follow the instructions at https://projectlombok.org.
 * 
 * @author Promineo
 *
 */
@Value
public class AtValue {

  private String firstName;
  private String lastName;
  private int age;

  public static void main(String[] args) {
    AtValue value = new AtValue("John", "Smith", 43);

    System.out.println(value);
  }
}
