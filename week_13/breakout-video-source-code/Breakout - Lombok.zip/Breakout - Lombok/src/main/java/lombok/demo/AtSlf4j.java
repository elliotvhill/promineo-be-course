// Copyright (c) 2023 by Promineo Tech.

package lombok.demo;

import lombok.Value;
import lombok.extern.slf4j.Slf4j;

/**
 * This class demonstrates the use of the Lombok annotation, @Slf4j. This
 * annotation adds an SLF4J logger instance variable named log. To demonstrate
 * the annotation in practice, Lombok must be installed into the IDE. Follow the
 * instructions at https://projectlombok.org.
 * 
 * @author Promineo
 *
 */
@Value
@Slf4j
public class AtSlf4j {

  private String firstName;
  private String lastName;
  private int age;

  public static void main(String[] args) {
    AtSlf4j slf = new AtSlf4j("Mary", "Jensen", 28);
    log.info("Name={}, age={}", slf.getFirstName() + " " + slf.getLastName(),
        slf.getAge());

    log.info("{}", slf);
  }

}
