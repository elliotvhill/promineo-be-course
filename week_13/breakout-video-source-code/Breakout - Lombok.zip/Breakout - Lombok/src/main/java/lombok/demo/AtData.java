// Copyright (c) 2023 by Promineo Tech.

package lombok.demo;

import lombok.Data;

/**
 * This class demonstrates the use of the Lombok annotation, @Data. This
 * annotation is used to create a mutable Java object. The annotation adds a
 * no-argument constructor and provides getters and setters for the instance
 * variables. Also added is .equals(), .hashCode(), and .toString(). To
 * demonstrate the annotation in practice, Lombok must be installed into the
 * IDE. Follow the instructions at https://projectlombok.org.
 * 
 * @author Promineo
 *
 */
@Data
public class AtData {

  private String firstName;
  private String lastName;
  private int age;

  public static void main(String[] args) {
    AtData data = new AtData();

    data.setAge(42);
    data.setFirstName("John");
    data.setLastName("Smith");

    System.out.println(data.getAge());
    System.out.println(data);
  }
}
