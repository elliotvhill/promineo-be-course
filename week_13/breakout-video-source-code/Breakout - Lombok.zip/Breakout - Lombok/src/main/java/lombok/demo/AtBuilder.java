// Copyright (c) 2023 by Promineo Tech.

package lombok.demo;

import lombok.Builder;
import lombok.Value;

/**
 * This class demonstrates the use of the Lombok annotation, @Builder. This
 * annotation adds a builder as an inner class. The builder implements the
 * Builder Design Pattern using a fluent API to avoid combinatorial explosion of
 * constructors. To demonstrate the annotation in practice, Lombok must be
 * installed into the IDE. Follow the instructions at https://projectlombok.org.
 * 
 * @author Promineo
 *
 */
@Builder
@Value
public class AtBuilder {

  private String firstName;
  private String lastName;
  private int age;

  public static void main(String[] args) {
    // @formatter:off
    AtBuilder builder = AtBuilder.builder()
        .firstName("Ralph")
        .lastName("Gency")
        .age(32)
        .build();
    // @formatter:on

    System.out.println(builder);
  }
}
