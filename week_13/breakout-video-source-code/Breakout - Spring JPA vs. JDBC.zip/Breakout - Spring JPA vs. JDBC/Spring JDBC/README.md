This project demonstrates how to write Spring JDBC. It is part of the Spring Boot segment in the backend course at Promineo Tech.

This project is featured in the breakout session Spring JPA s. Spring JDBC.