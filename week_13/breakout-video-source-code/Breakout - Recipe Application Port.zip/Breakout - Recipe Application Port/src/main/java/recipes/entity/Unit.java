// Copyright (c) 2023 by Promineo Tech.

package recipes.entity;

import java.util.HashSet;
import java.util.Set;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * This class provides JPA with information on how to manage the unit table.
 * 
 * @Entity Marks the class as one JPA will manage.
 * 
 * @Data Creates getters and setters for the instance variables. Also creates
 *       the .equals() and .hashCode() methods, as well as a .toString() method.
 * 
 * @author Promineo
 *
 */
@Entity
@Data
public class Unit {
  /*
   * @Id tells JPA that this is an identity (primary key) field. @GeneratedValue
   * tells JPA that the datasource will manage the primary key.
   */
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long unitId;

  private String unitNameSingular;
  private String unitNamePlural;

  /*
   * This is the "owning" side of the one-to-many relationship between unit and
   * ingredient. This variable contains a recursive reference to the Ingredient
   * class. Because of this it must be excluded from the .equals(), .hashCode(),
   * and .toString() methods.
   */
  @JsonIgnore
  @ToString.Exclude
  @EqualsAndHashCode.Exclude
  @OneToMany(mappedBy = "unit", cascade = CascadeType.ALL)
  private Set<Ingredient> ingredients = new HashSet<>();
}
