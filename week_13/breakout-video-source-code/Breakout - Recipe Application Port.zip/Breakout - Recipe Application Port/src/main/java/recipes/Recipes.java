// Copyright (c) 2023 by Promineo Tech.

package recipes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * This class is the entry point to the Java application. It contains the
 * {@link #main(String[])} method that starts Spring Boot.
 * 
 * @author Promineo
 *
 */
@SpringBootApplication
public class Recipes {

  /**
   * Start Spring Boot to run the recipe Web application.
   * 
   * @param args Unused.
   */
  public static void main(String[] args) {
    SpringApplication.run(Recipes.class, args);
  }
}
