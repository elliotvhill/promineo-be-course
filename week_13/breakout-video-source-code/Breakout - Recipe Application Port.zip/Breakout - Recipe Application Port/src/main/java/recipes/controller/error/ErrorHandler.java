// Copyright (c) 2023 by Promineo Tech.

package recipes.controller.error;

import java.util.Map;
import java.util.NoSuchElementException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * This class defines a global error handler. If an exception is thrown while
 * processing an HTTP request, it is mapped to a method in this class, if
 * available. If not, a 500 (Internal Server Error) status is returned by
 * Spring.
 * 
 * @RestControllerAdvice This annotation tells Spring to map errors to methods
 *                       in this class.
 * 
 * @author Promineo
 *
 */
@RestControllerAdvice
public class ErrorHandler {
  /**
   * Handler method for the {@link NoSuchElementException}.
   * 
   * @param e The thrown exception supplied to the method by Spring.
   * @return A map with the exception message.
   */
  @ExceptionHandler(NoSuchElementException.class)
  @ResponseStatus(code = HttpStatus.NOT_FOUND)
  public Map<String, String> handleNoSuchElementException(
      NoSuchElementException e) {
    return Map.of("message", e.getMessage());
  }
}
