// Copyright (c) 2023 by Promineo Tech.

package recipes.entity;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import lombok.Data;

/**
 * This class provides JPA with information on how to manage the recipe table.
 * 
 * @Entity Marks the class as one JPA will manage.
 * 
 * @Data Creates getters and setters for the instance variables. Also creates
 *       the .equals() and .hashCode() methods, as well as a .toString() method.
 * 
 * @author Promineo
 *
 */
@Entity
@Data
public class Recipe {
  /*
   * @Id tells JPA that this is an identity (primary key) field. @GeneratedValue
   * tells JPA that the datasource will manage the primary key.
   */
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)

  private Long recipeId;
  private String recipeName;
  private String notes;
  private Integer numServings;
  private LocalTime prepTime;
  private LocalTime cookTime;
  private LocalDateTime createdAt;

  /*
   * This is the "owning" side of the one-to-many relationship between the
   * recipe and ingredient tables.
   */
  @OneToMany(mappedBy = "recipe", cascade = CascadeType.ALL)
  private Set<Ingredient> ingredients = new HashSet<>();

  /*
   * This is the "owning" side of the one-to-many relationship between the
   * recipe and step tables.
   */
  @OneToMany(mappedBy = "recipe", cascade = CascadeType.ALL)
  private Set<Step> steps = new HashSet<>();

  /*
   * This is the "owning" side of the many-to-many relationship between recipe
   * and category. This specifies the characteristics of the join table that
   * links the two entities.
   */
  @ManyToMany(cascade = CascadeType.PERSIST)
  @JoinTable(name = "recipe_category",
      joinColumns = @JoinColumn(name = "recipe_id"),
      inverseJoinColumns = @JoinColumn(name = "category_id"))
  private Set<Category> categories = new HashSet<>();
}
