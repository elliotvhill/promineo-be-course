// Copyright (c) 2023 by Promineo Tech.

package recipes.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import lombok.extern.slf4j.Slf4j;
import recipes.entity.Recipe;
import recipes.service.RecipeService;

/**
 * The controller class contains methods that are mapped to HTTP requests. This
 * application is run under an embedded Tomcat application server. When an HTTP
 * request is sent to the application, it is received by the Tomcat server
 * listening on port 8080. Tomcat forwards the request to the Spring-supplied
 * Dispatcher Servlet. The Dispatcher Servlet then routes the request to methods
 * in this class if appropriate.
 * 
 * Class-level attributes:
 * 
 * @RestController Tells Spring Boot that this class handles REST requests.
 *                 Request and response payloads are in JSON by default and
 *                 Spring returns a 200 (OK) status by default.
 * 
 * @RequestMapping This specifies the base part of the URI as "/recipe". Other
 *                 mapping annotations on specific methods add on to the base
 *                 URI. For example, if a method
 *                 specified @GetMapping("/category"), the complete URI would be
 *                 "/recipe/category".
 * 
 * @Slf4j Used by Lombok to create an SLF4J logger assigned to an instance
 *        variable named "log".
 * 
 * @author Promineo
 *
 */
@RestController
@RequestMapping("/recipe")
@Slf4j
public class RecipeController {
  /* Ask Spring to inject a Managed Bean of type RecipeService. */
  @Autowired
  private RecipeService recipeService;

  /**
   * This method returns all recipes with all details. To call this method, send
   * an HTTP GET request to http://localhost:8080/recipe.
   * 
   * @return The list of all recipes.
   */
  @GetMapping
  public List<Recipe> fetchAllRecipes() {
    log.info("Retrieving all recipes");
    return recipeService.fetchAllRecipes();
  }

  /**
   * This method returns a single recipe given the recipe ID, which is passed in
   * the URI. To call this method, send an HTTP GET request as
   * http://localhost:8080/recipe/{ID}, where {ID} is the primary key of the
   * recipe to retrieve (i.e., http://localhost:8080/recipe/5 for a recipe with
   * recipe_id = 5).
   * 
   * @param recipeId The primary key value of the recipe to retrieve.
   * @return The recipe if found.
   */
  @GetMapping("/{recipeId}")
  public Recipe fetchRecipeById(@PathVariable Long recipeId) {
    log.info("Retrieving recipe with ID={}", recipeId);
    return recipeService.fetchRecipeById(recipeId);
  }
}
