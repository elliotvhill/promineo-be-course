// Copyright (c) 2023 by Promineo Tech.

package recipes.service;

import java.util.List;
import java.util.NoSuchElementException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import recipes.dao.RecipeDao;
import recipes.entity.Recipe;

/**
 * This class provides service-layer methods for the recipe application. It
 * manages transactions and calls DAO-layer methods to manage recipe data.
 * 
 * @author Promineo
 *
 */
@Service
public class RecipeService {
  @Autowired
  private RecipeDao recipeDao;

  /**
   * Retrieve all recipes.
   * 
   * @return A list of all recipes.
   */
  @Transactional
  public List<Recipe> fetchAllRecipes() {
    return recipeDao.findAll();
  }

  /**
   * Returns a single recipe by recipe ID.
   * 
   * @param recipeId The ID of the recipe to retrieve.
   * @return The recipe if found.
   */
  @Transactional
  public Recipe fetchRecipeById(Long recipeId) {
    return findRecipeById(recipeId);
  }

  /**
   * Retrieve and return a recipe if found.
   * 
   * @param recipeId The ID of the recipe to retrieve.
   * @return The recipe.
   * @throws NoSuchElementException Thrown if the given ID is not found.
   */
  private Recipe findRecipeById(Long recipeId) {
    return recipeDao.findById(recipeId)
        .orElseThrow(() -> new NoSuchElementException(
            "Recipe with ID=" + recipeId + " was not found."));
  }

}
