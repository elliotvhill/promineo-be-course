// Copyright (c) 2023 by Promineo Tech.

package recipes.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import recipes.entity.Recipe;

/**
 * This interface defines methods involving the {@link Recipe} entity. Spring
 * JPA provides the backing implementation for all defined methods.
 * 
 * @author Promineo
 *
 */
public interface RecipeDao extends JpaRepository<Recipe, Long> {

}
